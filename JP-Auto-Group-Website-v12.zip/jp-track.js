/* JP Auto Group — consent, analytics events and optional business details.
   Google Tag Manager loads from each page's <head> with Consent Mode set to 'denied'; this file handles the banner and consent updates. */
(function () {
  'use strict';
  var cfg = window.JP_CONFIG || {};
  var KEY = 'jp_consent_v1';
  window.dataLayer = window.dataLayer || [];
  function gtag() { window.dataLayer.push(arguments); }
  function push(obj) { try { window.dataLayer.push(obj); } catch (e) {} }
  function get() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function set(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }

  /* Consent Mode defaults: everything denied until the visitor opts in. */
  if (!window.__jpConsentInit) gtag('consent', 'default', { ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'denied' });

  var gtmLoaded = false;
  function loadGTM() {
    if (gtmLoaded || !cfg.gtmId || !/^GTM-[A-Z0-9]+$/.test(cfg.gtmId)) return;
    if (document.querySelector('script[src*="googletagmanager.com/gtm.js"]')) { gtmLoaded = true; return; }
    gtmLoaded = true;
    window.dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' });
    var s = document.createElement('script');
    s.async = true; s.src = 'https://www.googletagmanager.com/gtm.js?id=' + cfg.gtmId;
    document.head.appendChild(s);
  }
  function grant() {
    gtag('consent', 'update', { ad_storage: 'granted', ad_user_data: 'granted', ad_personalization: 'granted', analytics_storage: 'granted' });
    loadGTM();
  }

  /* Respect Global Privacy Control (California): treat as an automatic decline. */
  var gpc = navigator.globalPrivacyControl === true;
  if (gpc && !get()) set('declined');
  if (get() === 'accepted' && !gpc) grant();

  /* Cookie banner — only shown when a tracking container is configured. */
  function banner(force) {
    if (!cfg.gtmId) return;
    if (!force && (get() || gpc)) return;
    if (document.getElementById('jpConsent')) return;
    var css = document.createElement('style');
    css.textContent = '#jpConsent{position:fixed;left:16px;bottom:16px;max-width:400px;background:#101b29;color:#fff;border-radius:14px;padding:18px 20px;box-shadow:0 16px 50px #0006;z-index:99;font:14px/1.5 system-ui,Arial,sans-serif}#jpConsent p{margin:0 0 12px;font-size:13px}#jpConsent a{color:#cfe0f3}#jpConsent div{display:flex;gap:10px;flex-wrap:wrap}#jpConsent button{border:0;border-radius:9px;padding:11px 18px;font:700 14px system-ui,Arial;cursor:pointer}#jpConsent .ok{background:#b42332!important;color:#fff!important}#jpConsent .no{background:#e7edf4!important;color:#15263b!important}#jpConsent button:focus-visible{outline:3px solid #85a9d4;outline-offset:2px}@media(max-width:800px){#jpConsent{right:12px;left:12px;max-width:none;bottom:calc(84px + env(safe-area-inset-bottom,0px));padding:14px 16px}}';
    document.head.appendChild(css);
    var el = document.createElement('div');
    el.id = 'jpConsent'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Cookie preferences');
    el.innerHTML = '<p>We use optional cookies for analytics and ad measurement, only if you allow it. Change anytime. See our <a href="/privacy/">Privacy Policy</a>.</p><div><button type="button" class="ok">Accept</button><button type="button" class="no">Decline</button></div>';
    el.querySelector('.ok').onclick = function () { set('accepted'); grant(); el.remove(); };
    el.querySelector('.no').onclick = function () {
      set('declined'); el.remove();
      gtag('consent', 'update', { ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'denied' });
    };
    document.body.appendChild(el);
  }
  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('[data-cookie-settings]');
    if (t) { e.preventDefault(); banner(true); }
  });

  /* Optional business details: click-to-call, and richer structured data. */
  function phoneLinks() {
    if (!cfg.phone || !/^\+?[0-9]{10,15}$/.test(cfg.phone)) return;
    var label = cfg.phoneDisplay || cfg.phone;
    var foot = document.querySelector('footer');
    if (foot && !foot.querySelector('a[href^="tel:"]')) {
      var p = document.createElement('p');
      p.innerHTML = 'Call us: <a href="tel:' + cfg.phone + '" style="color:#fff;font-weight:700"></a>';
      p.querySelector('a').textContent = label;
      foot.appendChild(p);
    }
  }
  function enrichSchema() {
    var node = document.getElementById('jp-ld');
    if (!node) return;
    try {
      var data = JSON.parse(node.textContent);
      var biz = (data['@graph'] || []).filter(function (x) { return x['@id'] && /#business$/.test(x['@id']); })[0];
      if (!biz) return;
      if (cfg.phone) biz.telephone = cfg.phone;
      if (cfg.email) biz.email = cfg.email;
      if (cfg.streetAddress && cfg.city && cfg.postalCode) {
        biz.address = { '@type': 'PostalAddress', streetAddress: cfg.streetAddress, addressLocality: cfg.city, addressRegion: cfg.region || 'CA', postalCode: cfg.postalCode, addressCountry: 'US' };
      }
      if (cfg.sameAs && cfg.sameAs.length) biz.sameAs = cfg.sameAs;
      node.textContent = JSON.stringify(data);
    } catch (e) {}
  }

  /* Events: form_start, click_to_call, cta_click, and generate_lead (thank-you page only, once per real submission). */
  var started = {};
  document.addEventListener('input', function (e) {
    var f = e.target.closest && e.target.closest('form');
    if (!f) return;
    var name = f.getAttribute('name') || f.id || 'form';
    if (!started[name]) { started[name] = 1; push({ event: 'form_start', form_name: name }); }
  });
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a');
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (href.indexOf('tel:') === 0) push({ event: 'click_to_call' });
    else if (a.classList.contains('btn')) push({ event: 'cta_click', cta_text: (a.textContent || '').trim().slice(0, 40), cta_target: href.slice(0, 80) });
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || !f.hasAttribute || !f.hasAttribute('data-netlify') || f.id === 'requestForm') return;
    try { sessionStorage.setItem('jp_lead_success', f.getAttribute('name') || 'form'); } catch (err) {}
  }, true);


  /* Campaign attribution: save ad/UTM click data for this visit, and attach it to every form. */
  var SRC_KEYS = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','gbraid','wbraid','fbclid','msclkid'];
  function ss(k, v) { try { if (v === undefined) return sessionStorage.getItem(k) || ''; sessionStorage.setItem(k, v); } catch (e) { return ''; } }
  function captureSource() {
    var q = new URLSearchParams(location.search);
    SRC_KEYS.forEach(function (k) { var v = q.get(k); if (v) ss(k, v.slice(0, 200)); });
    if (!ss('jp_first_landing')) ss('jp_first_landing', location.pathname);
    if (!ss('jp_referrer')) { try { ss('jp_referrer', document.referrer ? new URL(document.referrer).origin : 'direct'); } catch (e) { ss('jp_referrer', 'direct'); } }
  }
  function fillForms() {
    var vals = { first_landing_page: ss('jp_first_landing'), referrer: ss('jp_referrer') };
    SRC_KEYS.forEach(function (k) { vals[k] = ss(k); });
    document.querySelectorAll('form[data-netlify]').forEach(function (f) {
      Object.keys(vals).forEach(function (k) { var i = f.querySelector('input[name="' + k + '"]'); if (i) i.value = vals[k]; });
    });
  }
  captureSource();
  document.addEventListener('submit', fillForms, true);

  /* Homepage multi-step form: report each step so drop-off is visible. */
  var stepNo = 1;
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#continue');
    if (b) { stepNo += 1; push({ event: 'form_step', form_name: 'vehicle-request', step_number: stepNo }); }
  });

  /* Sticky Contact + Quote bar on mobile. */
  function mobileBar() {
    var path = location.pathname;
    if (/^\/(thank-you|privacy|disclaimer|contact)\/?$/.test(path)) return;
    var st = document.createElement('style');
    st.textContent = '.jp-mbar{display:none}@media(max-width:800px){.jp-mbar{display:flex;gap:10px;position:fixed;left:0;right:0;bottom:0;z-index:90;padding:10px 14px calc(10px + env(safe-area-inset-bottom,0px));background:#fff;box-shadow:0 -6px 24px #0002}.jp-mbar a{flex:1;text-align:center;text-decoration:none;font:700 15px/1 system-ui,Arial,sans-serif;padding:14px 10px;border-radius:10px}.jp-mbar .c{background:#fff;color:#101b29;border:1.5px solid #101b29}.jp-mbar .q{background:#b42332;color:#fff}body{padding-bottom:76px}.mobile-cta{display:none!important}}';
    document.head.appendChild(st);
    var quote = (path === '/' || /^\/(personal|commercial)-vehicles\/?$/.test(path)) ? '#request' : '/#request';
    var bar = document.createElement('div'); bar.className = 'jp-mbar';
    bar.innerHTML = '<a class="c" href="/contact/">Contact us</a><a class="q" href="' + quote + '">Get a quote</a>';
    document.body.appendChild(bar);
  }

  function ready() {
    mobileBar();
    phoneLinks(); enrichSchema(); banner(false);
    if (/^\/thank-you\/?$/.test(location.pathname)) {
      var form = null;
      try { form = sessionStorage.getItem('jp_lead_success'); sessionStorage.removeItem('jp_lead_success'); } catch (e) {}
      if (form) {
        var src = {};
        ['utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'fbclid'].forEach(function (k) { try { src[k] = sessionStorage.getItem(k) || ''; } catch (e) {} });
        push({ event: 'generate_lead', form_name: form === '1' ? 'vehicle-request' : form, utm_source: src.utm_source, utm_medium: src.utm_medium, utm_campaign: src.utm_campaign });
      }
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
})();
