/* JP Auto Group — site settings. Fill in the values below, save, and redeploy.
   Leave a value blank ('') to keep that feature switched off. Nothing here is guessed or invented. */
window.JP_CONFIG = {
  gtmId: 'GTM-T7BK7KHH',            // Google Tag Manager container. Also written into every page's <head> by the build, with Consent Mode 'denied' until a visitor accepts.
  phone: '+17147322017',            // Click-to-call number in international format, e.g. '+19515550123'
  phoneDisplay: '(714) 732-2017',     // How the number is shown, e.g. '(951) 555-0123'
  email: '',            // Public business email (leave blank: the Contact page form is used instead)
  streetAddress: '151 North Tustin Ave, Space C-5',    // e.g. '123 Main St'
  city: 'Tustin',             // e.g. 'Corona'
  region: 'CA',
  postalCode: '92780',       // e.g. '92882'
  dealerLicense: '84214',   // California DMV dealer license number
  sameAs: ['https://www.google.com/maps?cid=13029564546583541541']            // Public profile URLs, e.g. Google Business Profile, Facebook, Instagram, Yelp
};
